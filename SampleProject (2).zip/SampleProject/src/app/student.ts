export class Student{
    name:String;
    email:String;
    password:String;
        id?: number;
        constructor(){

        }
}