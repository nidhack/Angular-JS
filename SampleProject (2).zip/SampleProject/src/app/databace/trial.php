
<?php 

$con = mysqli_connect("localhost","root","","trials");
{
	$name =$_POST['name'];
	
    $email=$_POST['email'];
    $password =$_POST['password'];

		$sql1="insert into tbl_reg(name,email,password) values ('$name','$email','$password')";
		
	$res=mysqli_query($con,$sql1) or die(mysqli_error($con));

	
}


?> 
